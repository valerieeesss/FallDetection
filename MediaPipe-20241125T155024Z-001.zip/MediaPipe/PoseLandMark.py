import os
import csv
import cv2
import mediapipe as mp

# Initialize MediaPipe Pose
mp_pose = mp.solutions.pose
mp_drawing = mp.solutions.drawing_utils

# Path to the folder containing images (with subfolders)
image_folder = '/Users/timchen/Desktop/MediaPipe/images/'
# Folder to save processed images
csv_file = 'pose_landmarks.csv'
output_folder = '/Users/timchen/Desktop/MediaPipe/output_images/'
csv_file = 'pose_landmarks.csv'

# Ensure output folder exists
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Initialize CSV file for storing landmarks
with open(csv_file, mode='w', newline='') as file:
    writer = csv.writer(file)
    header = ['filename'] + [f'landmark_{i}_x' for i in range(33)] + [f'landmark_{i}_y' for i in range(33)] + ['label']
    writer.writerow(header)

    # Initialize Pose model
    with mp_pose.Pose(static_image_mode=True) as pose:
        for root, dirs, files in os.walk(image_folder):  # Recursively go through subfolders
            for image_file in files:
                image_path = os.path.join(root, image_file)
                image = cv2.imread(image_path)

                # Skip if image could not be read
                if image is None:
                    continue

                # Convert image to RGB
                rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

                # Process the image and detect landmarks
                results = pose.process(rgb_image)

                if results.pose_landmarks:
                    landmarks = []
                    for landmark in results.pose_landmarks.landmark:
                        landmarks.extend([landmark.x, landmark.y])


                    # Label based on file naming convention
                    if 'sit' in image_file.lower():
                        label = 'sitting'
                    elif 'stand' in image_file.lower():
                        label = 'standing'
                    elif 'lying' in image_file.lower():
                        label = 'lying down'
                    else:
                        label = 'unknown' 

                    # Write to CSV file
                    writer.writerow([image_file] + landmarks + [label])

                    # Draw landmarks on the image
                    mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS)

                    # Save the processed image with landmarks
                    relative_path = os.path.relpath(image_path, image_folder)
                    output_image_path = os.path.join(output_folder, relative_path)

                    # Ensure the directory for the output image exists
                    os.makedirs(os.path.dirname(output_image_path), exist_ok=True)

                    cv2.imwrite(output_image_path, image)

print("Landmark extraction complete. Images and data saved.")
