import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.utils import to_categorical
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report, confusion_matrix

# Load the data
csv_file = 'pose_landmarks.csv'
data = pd.read_csv(csv_file)

# Preprocess the labels (target)
pose_labels = ['standing', 'sitting', 'lying down']
data = data[data['label'].isin(pose_labels)]  # Filter relevant poses

# Encode labels into numeric values
le = LabelEncoder()
data['label'] = le.fit_transform(data['label'])  # Encode pose labels

# Prepare features (X) and labels (y)
X = data.drop(columns=['filename', 'label'])  # Drop unnecessary columns
y = to_categorical(data['label'])  # Convert labels to one-hot encoded format

# Convert features to numeric data types (ensures compatibility)
X = X.apply(pd.to_numeric, errors='coerce').fillna(0)

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Build a Feedforward Neural Network
model = Sequential([
    Dense(128, input_shape=(X_train.shape[1],), activation='relu'),
    Dense(64, activation='relu'),
    Dense(32, activation='relu'),
    Dense(y_train.shape[1], activation='softmax')  # Output layer with softmax for classification
])

# Compile the model
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Train the model
model.fit(X_train, y_train, epochs=20, batch_size=32, validation_split=0.2)

# Evaluate the model on test data
test_loss, test_accuracy = model.evaluate(X_test, y_test)
print(f"Test Accuracy: {test_accuracy:.2f}")

# Predict on test data
y_pred = np.argmax(model.predict(X_test), axis=1)
y_true = np.argmax(y_test, axis=1)

# Display a classification report
print(classification_report(y_true, y_pred, target_names=pose_labels))

# Confusion matrix
conf_matrix = confusion_matrix(y_true, y_pred)
print("Confusion Matrix:\n", conf_matrix)

# Visualize the confusion matrix using Seaborn heatmap
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=pose_labels, yticklabels=pose_labels)
plt.ylabel('Actual Pose')
plt.xlabel('Predicted Pose')
plt.title('Confusion Matrix')

# Save the confusion matrix as an image
plt.savefig('confusion_matrix.png')

# Display the plot
plt.show()
