import cv2
import mediapipe as mp
import pandas as pd
import time
import csv
from sklearn.ensemble import RandomForestClassifier
import os

# Load your trained RandomForest classifier
rf_classifier = RandomForestClassifier(n_estimators=100, random_state=42)
data = pd.read_csv('pose_landmarks.csv')
X = data.drop(columns=['filename', 'label'])
y = data['label']
rf_classifier.fit(X, y)

# Initialize Mediapipe Pose and drawing utilities
mp_pose = mp.solutions.pose
mp_drawing = mp.solutions.drawing_utils

# Initialize video capture
cap = cv2.VideoCapture(0)

# Create a new CSV file for saving predictions with a unique name
output_csv = f'prediction_landmarks_{time.strftime("%Y%m%d-%H%M%S")}.csv'
with open(output_csv, mode='w', newline='') as file:
    writer = csv.writer(file)
    header = ['time', 'prediction'] + [f'landmark_{i}_x' for i in range(33)] + [f'landmark_{i}_y' for i in range(33)]
    writer.writerow(header)

with mp_pose.Pose(static_image_mode=False, min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose:
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # Convert the BGR image to RGB for Mediapipe processing
        rgb_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        rgb_image.flags.writeable = False

        # Make pose detections
        results = pose.process(rgb_image)

        # Convert back to BGR for OpenCV rendering
        rgb_image.flags.writeable = True
        frame = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2BGR)

        # Extract pose landmarks if available
        if results.pose_landmarks:
            landmarks = []
            for landmark in results.pose_landmarks.landmark:
                landmarks.extend([landmark.x, landmark.y])

            # Convert the landmarks to DataFrame format for prediction
            landmarks_df = pd.DataFrame([landmarks])

            # Predict the pose using the RandomForest classifier
            current_prediction = rf_classifier.predict(landmarks_df)[0]

            # Save landmarks and prediction to the new CSV
            timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
            with open(output_csv, mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([timestamp, current_prediction] + landmarks)

            # Draw the pose landmarks on the frame
            mp_drawing.draw_landmarks(
                frame, results.pose_landmarks, mp_pose.POSE_CONNECTIONS)

            # Create a background box for the text
            text = f'Pose: {current_prediction}'
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 1
            font_thickness = 2
            text_size, _ = cv2.getTextSize(text, font, font_scale, font_thickness)
            text_x, text_y = 50, 50
            box_coords = ((text_x - 10, text_y - 10), (text_x + text_size[0] + 10, text_y + text_size[1] + 10))

            # Draw a semi-transparent box
            cv2.rectangle(frame, box_coords[0], box_coords[1], (0, 0, 0), cv2.FILLED)
            cv2.addWeighted(frame, 0.6, frame, 0.4, 0, frame)  # Adjust transparency

            # Add text on top of the background box
            cv2.putText(frame, text, (text_x, text_y + text_size[1]),
                        font, font_scale, (255, 255, 255), font_thickness, cv2.LINE_AA)

        # Display the video feed with the landmarks and prediction
        cv2.imshow('Pose Detection with Prediction', frame)

        # Press 'q' or 'Esc' to exit
        key = cv2.waitKey(10) & 0xFF
        if key == ord('q') or key == 27:  # 27 is the ASCII code for 'Esc'
            break

# Release resources
cap.release()
cv2.destroyAllWindows()
