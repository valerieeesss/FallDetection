import os
import cv2
import csv
from ultralytics import YOLO

# Path to the folder containing images (with subfolders)
image_folder = '/Users/timchen/Desktop/YoloPose/images/'
# Folder to save processed images and CSV
csv_file = 'pose_landmarks.csv'
output_folder = '/Users/timchen/Desktop/YoloPose/output_images/'

# Ensure output folder exists
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Initialize YOLOPose model
model = YOLO('yolo11n-pose.pt') 

def process_images_and_save_landmarks():
    """Processes images from the folder, detects poses, saves landmarks to a CSV, and saves processed images."""
    # Initialize CSV file for storing landmarks
    with open(csv_file, mode='w', newline='') as file:
        writer = csv.writer(file)
        header = ['filename'] + [f'landmark_{i}_x' for i in range(17)] + [f'landmark_{i}_y' for i in range(17)] + ['label']
        writer.writerow(header)

        # Iterate through the image folder
        for root, dirs, files in os.walk(image_folder):
            for image_file in files:
                image_path = os.path.join(root, image_file)
                image = cv2.imread(image_path)

                # Skip if image could not be loaded
                if image is None:
                    print(f"Failed to load image: {image_file}")
                    continue

                # Detect pose landmarks using YOLOPose
                results = model(image)

                if results and results[0].keypoints is not None:
                    keypoints = results[0].keypoints.data.cpu().numpy()[0]
                    landmarks = []
                    for point in keypoints:
                        landmarks.extend([point[0] / image.shape[1], point[1] / image.shape[0]])

                    # Label based on file naming convention
                    if 'sit' in image_file.lower():
                        label = 'sitting'
                    elif 'stand' in image_file.lower():
                        label = 'standing'
                    elif 'lying' in image_file.lower():
                        label = 'lying down'
                    else:
                        label = 'unknown'

                    # Write to CSV file
                    writer.writerow([image_file] + landmarks + [label])

                    # Draw landmarks on the image
                    for point in keypoints:
                        cv2.circle(image, (int(point[0]), int(point[1])), 5, (0, 255, 0), -1)

                    # Save the processed image with landmarks
                    relative_path = os.path.relpath(image_path, image_folder)
                    output_image_path = os.path.join(output_folder, relative_path)
                    os.makedirs(os.path.dirname(output_image_path), exist_ok=True)
                    cv2.imwrite(output_image_path, image)

    print("Pose landmarks extracted and saved to CSV.")

process_images_and_save_landmarks()
